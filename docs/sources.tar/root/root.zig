const c = @cImport({
    @cInclude("SDL3/SDL.h");
    @cInclude("SDL3_ttf/SDL_ttf.h");
});

const std = @import("std");
const testing = std.testing;

pub const init = @import("init.zig");
pub const video = @import("video.zig");
pub const render = @import("render.zig");
pub const events = @import("events.zig");
pub const rect = @import("rect.zig");
pub const pixels = @import("pixels.zig");
pub const surface = @import("surface.zig");
pub const timer = @import("timer.zig");
pub const errors = @import("errors.zig");
pub const ttf = @import("ttf.zig");

const MonitorInfo = struct {
    display_id: i32,
    x: i32,
    y: i32,
    width: i32,
    height: i32,
};

fn runLoldongs(monitor: MonitorInfo) !void {
    // Initialize SDL with video subsystem
    try init.init(.{ .video = true });
    defer init.quit();

    // Initialize TTF
    try ttf.Font.init();
    defer ttf.Font.quit();

    // Create a fullscreen window on the specified monitor
    var window = try video.Window.create(
        "loldongs",
        monitor.width,
        monitor.height,
        .{ .fullscreen = true },
    );
    defer window.destroy();

    // Set window position
    window.setPosition(monitor.x, monitor.y);

    // Create a renderer
    var renderer = try render.Renderer.create(window, .{
        .accelerated = true,
        .vsync = true,
    });
    defer renderer.destroy();

    // Load font
    var font = try ttf.Font.load("/System/Library/Fonts/ComicCodeLigatures-Regular.otf", 72);
    defer font.close();

    // Main loop
    var running = true;
    while (running) {
        // Handle events
        while (events.pollEvent()) |event| {
            switch (event) {
                .quit => running = false,
                .key_down => |key| {
                    if (key.keycode == .escape) running = false;
                },
                else => {},
            }
        }

        // Clear screen
        try renderer.setColor(pixels.Colors.black);
        try renderer.clear();

        // Render text
        const text_surface = try font.renderBlended("LOLDONGS", pixels.Colors.white);
        defer c.SDL_DestroySurface(text_surface);

        // Create texture from surface
        const text_texture = c.SDL_CreateTextureFromSurface(@ptrCast(renderer.handle), text_surface) orelse return errors.SDLError.TextureCreationFailed;
        defer c.SDL_DestroyTexture(text_texture);

        // Get texture dimensions
        var text_width: f32 = undefined;
        var text_height: f32 = undefined;
        if (!c.SDL_GetTextureSize(text_texture, &text_width, &text_height)) {
            return errors.SDLError.TextureQueryFailed;
        }

        // Center text
        const dest_rect = c.SDL_FRect{
            .x = @as(f32, @floatFromInt(monitor.width)) / 2.0 - text_width / 2.0,
            .y = @as(f32, @floatFromInt(monitor.height)) / 2.0 - text_height / 2.0,
            .w = text_width,
            .h = text_height,
        };

        // Draw text
        _ = c.SDL_RenderTexture(@ptrCast(renderer.handle), text_texture, null, &dest_rect);

        // Present
        try renderer.present();

        // Small delay to prevent maxing out CPU
        timer.delay(16); // roughly 60 FPS
    }
}

pub fn main() !void {
    // Get command line args
    const args = try std.process.argsAlloc(std.heap.page_allocator);
    defer std.process.argsFree(std.heap.page_allocator, args);

    // Check if we're a child process
    if (args.len > 1 and std.mem.eql(u8, args[1], "--monitor")) {
        // Parse monitor info from args
        const monitor = MonitorInfo{
            .display_id = try std.fmt.parseInt(i32, args[2], 10),
            .x = try std.fmt.parseInt(i32, args[3], 10),
            .y = try std.fmt.parseInt(i32, args[4], 10),
            .width = try std.fmt.parseInt(i32, args[5], 10),
            .height = try std.fmt.parseInt(i32, args[6], 10),
        };
        try runLoldongs(monitor);
        return;
    }

    // Parent process - spawn children for each monitor
    try init.init(.{ .video = true });
    defer init.quit();

    // Get displays
    var num_displays: i32 = undefined;
    const displays = c.SDL_GetDisplays(&num_displays) orelse return errors.SDLError.InitializationFailed;
    if (num_displays <= 0) {
        return errors.SDLError.InitializationFailed;
    }

    // Allocate array for child processes
    var processes = std.ArrayList(*std.process.Child).init(std.heap.page_allocator);
    defer processes.deinit();

    // For each display
    var i: usize = 0;
    while (i < @as(usize, @intCast(num_displays))) : (i += 1) {
        const display_id = displays[i];

        // Get display bounds
        var bounds: c.SDL_Rect = undefined;
        if (!c.SDL_GetDisplayBounds(display_id, &bounds)) {
            continue;
        }

        // Create child process
        var child = try std.process.Child.init(&[_][]const u8{
            try std.fs.selfExePathAlloc(std.heap.page_allocator),
            "--monitor",
            try std.fmt.allocPrint(std.heap.page_allocator, "{d}", .{i}),
            try std.fmt.allocPrint(std.heap.page_allocator, "{d}", .{bounds.x}),
            try std.fmt.allocPrint(std.heap.page_allocator, "{d}", .{bounds.y}),
            try std.fmt.allocPrint(std.heap.page_allocator, "{d}", .{bounds.w}),
            try std.fmt.allocPrint(std.heap.page_allocator, "{d}", .{bounds.h}),
        }, std.heap.page_allocator);
        child.stderr_behavior = .Ignore;
        child.stdout_behavior = .Ignore;

        try processes.append(&child);
        try child.spawn();
    }

    // Wait for all child processes
    for (processes.items) |child| {
        _ = try child.wait();
    }
}

test {
    _ = init;
    _ = video;
    _ = render;
    _ = events;
    _ = rect;
    _ = pixels;
    _ = surface;
    _ = timer;
    _ = errors;
    _ = ttf;
    testing.refAllDecls(@This());
}
